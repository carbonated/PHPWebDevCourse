<?php

class NewsModel {
	
	public function GetNewsData($id) {
		return DB::table('news')->where('id', $id)->first();
	}
	
	
	
}
