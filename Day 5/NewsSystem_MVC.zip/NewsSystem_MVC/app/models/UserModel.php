<?php

class UserModel {
	
	public function GetUserData($id) {
		return DB::table('users')->where('id', $id)->first();
	}
	
	public function RegisterUser($username, $password) {
		
		$fields = array(
			'username' => trim($username),
			'password' => trim($password)
		);
		
		$rules = array(
			'username' => 'min:4|max:20|unique:users',
			'password' => 'min:4|max:15'
		);
		
		
		$validator = Validator::make($fields, $rules);
		if($validator->fails()) {
			return $validator->messages();
		} else {
			$insertUser = DB::table('users')->insert(array('username' => $fields['username'], 'password' => $fields['password']));
			if($insertUser) {
				return 'Регистрацията е успешна';
			} else {
				return 'Възникна грешка';
			}
		}
		
		
	}
	
}
