<?php

return array(
	'cats' => array(
		0 => 'Всякакви',
		1 => 'Политически',
		2 => 'Sports',
		3 => 'Клюки'
	)
);
