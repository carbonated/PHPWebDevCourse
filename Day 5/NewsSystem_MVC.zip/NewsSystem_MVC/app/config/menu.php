<?php

return array(
	'items' => array(
		array(
			'title' => 'Начало',
			'page' => action('MainController@index'), /*
			 * не попълваме стойност, защото в логиката в index.php сме
			 * направили switch при default винаги да показва началната страница
			 */
			'show' => 0
		),
		array(
			'title' => 'Регистрация',
			'page' => action('UserController@register'),
			'show' => 1
		),
		array(
			'title' => 'Логин',
			'page' => action('UserController@login'),
			'show' => 1
		),
		array(
			'title' => 'Добави новина',
			'page' => action('NewsController@addNews'),
			'show' => 2
		),
		array(
			'title' => 'Изход',
			'page' => action('UserController@logout'),
			'show' => 2
		)
	)
);
