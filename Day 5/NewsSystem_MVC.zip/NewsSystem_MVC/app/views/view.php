<div id="container">
	<h1 class="center-text">Преглед на новина:</h1>
	<hr>
	<?php
	if (empty($errors)) { //Проверяваме за грешки и ако няма визуализираме новината
		?>
		<h2><?php echo htmlspecialchars($news->title); ?></h2>
		<h3><?php echo Config::get('cats.cats')[$news->cat]; ?></h3>
		<h3>От <?php echo $author->username; ?></h3>
		<small>
			<?php
			/*
			 * функцията date приема 2 параметъра, като втория не е задължителен:
			 * 1. начинът по който да покаже датата (string) - http://bg2.php.net/manual/en/function.date.php
			 * 2. дата във формата на UNIX timestamp (ако не се посочи взима текущата дата time())
			 */
			echo date("d.m.yг. в H:i:sч.", $news->time);
			?>
		</small><br>
		<img src="<?php echo asset('uploads/'.$news->photo); ?>" width="50%" height="50%"><br>
		<p><?php echo $news->content; ?></p>
		<?php
	} else { //Но ако има изкарваме грешките
		echo '<ul>';
		foreach ($errors as $error) {
			echo '<li>' . $error . '</li>';
		}
		echo '</ul>';
	}
	?>
</div>

<div class="clear-fix"></div>

