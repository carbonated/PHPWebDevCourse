<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $title; ?></title>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="<?php echo asset('css/style.css'); ?>">
	</head>
	<body>
		<div id="content">
			<div id="header">
				<h1>PHP News System</h1>
			</div>