<div id="footer">
	<small>Курс PHP Уеб Разработка</small>
</div>
</div>
</body>
</html>
