
<form method="POST" action="">
	Потребителско име:<br>
	<input type="text" name="username"><br>
	Парола:<br>
	<input type="password" name="password"><br>
	<input type="submit" name="submit" value="Регистрирай се!">
</form>
