<div id="container">
	<h1 class="center-text">Начало:</h1>
	<hr>
	<?php
	$i = 1;
	foreach ($news as $item) {
		echo $i . '. <a href="' . action('NewsController@view', [$item->id]) . '">' . htmlspecialchars($item->title) . '</a><br>';
		$i++;
	}
	?>
</div>

<div class="clear-fix"></div>

