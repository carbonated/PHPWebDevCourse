<?php

class UserController extends Controller {
	
	public static function IsUserLogged() {
		if(Session::get('isLogged')) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
	
	public function register() {
		$data = array();
		$data['title'] = 'Регистрация';
		
		$data_menu = array();
		$data_menu['menu'] = Config::get('menu.items');
		$data_menu['isUserLogged'] = UserController::IsUserLogged();
		
		
		
		echo View::make('header', $data);
		echo View::make('menu', $data_menu);
		echo View::make('register');
		echo View::make('footer');
	}
	
	public function registerPost() {
		$username = Input::get('username');
		$password = Input::get('password');
		
		$UM = new UserModel();
		echo $UM->RegisterUser($username, $password);
	}
	
}
