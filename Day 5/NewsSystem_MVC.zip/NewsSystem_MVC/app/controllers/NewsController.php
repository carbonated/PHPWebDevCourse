<?php

class NewsController extends Controller {
	
	public function view($id) {
		$NM = new NewsModel();
		$getNews = $NM->GetNewsData($id);
		
		$data = array();
		$data_main['errors'] = array();
		$data_menu = array();
		$data_menu['menu'] = Config::get('menu.items');
		$data_menu['isUserLogged'] = UserController::IsUserLogged();
		
		if(empty($getNews)) {
			$data['title'] = 'Няма такава новина';
			$data_main['errors'][] = 'Няма такава новина';
			
			echo View::make('header', $data);
			echo View::make('menu', $data_menu);
			echo View::make('view', $data_main);
			echo View::make('footer');
			
		} else {
			
			$data['title'] = 'Преглед на новина - '.$getNews->title;

			

			$data_main['news'] = $getNews;
			$UM = new UserModel();
			$author = $UM->GetUserData($getNews->user_id);
			$data_main['author'] = $author;

			echo View::make('header', $data);
			echo View::make('menu', $data_menu);
			echo View::make('view', $data_main);
			echo View::make('footer');
		}
	}
	
}
