<?php

class MainController extends Controller {
	
	public function index() {		
		$data = array();
		$data['title'] = 'Начало';
		
		$data_menu = array();
		$data_menu['menu'] = Config::get('menu.items');
		$data_menu['isUserLogged'] = UserController::IsUserLogged();
		
		$latestNews = DB::table('news')->orderBy('id', 'desc')->take(10)->get();
		$data_main = array();
		$data_main['news'] = $latestNews;
		
		echo View::make('header', $data);
		echo View::make('menu', $data_menu);
		echo View::make('main', $data_main);
		echo View::make('footer');
	}
	
	
}
